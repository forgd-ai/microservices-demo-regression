#!/usr/bin/env bash
set -euo pipefail

project_dir="${CLAUDE_PROJECT_DIR:-$PWD}"
hook_path="${project_dir}/.git/hooks/pre-push"

if [[ ! -x "$hook_path" ]]; then
  echo "WARNING: The preflight git pre-push hook is not installed. Run /install-preflight-hook to install it."
fi

exit 0
