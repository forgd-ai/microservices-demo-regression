# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repo is

A Claude Code plugin (`preflight`, see `.claude-plugin/plugin.json`) that gates `git push` behind automated quality checks. Currently scaffolded — directory structure and `plugin.json` exist, but `skills/*.md`, `agents/*.md`, `git-hooks/pre-push`, and `scripts/*.sh` are empty and need implementation.

**Always read `plan.md` first.** It is the design source of truth — it specifies each file's purpose, the contracts between components, and the key architectural decisions. Do not re-derive these from scratch.

## Architecture (the parts that span multiple files)

**Three-layer enforcement, single validator.** See the "Enforcement layers" section below. All layers shell out to `scripts/check-stamp.sh` — the **single source of truth** for stamp validation. When modifying gate behavior, change `check-stamp.sh`, not the callers, or the layers will drift.

**Report-as-contract.** `/preflight` (the skill) orchestrates two sub-agents in parallel via the `Agent` tool — `agents/diff-summarizer.md` (FOCUS/SKIM/SKIP triage) and `agents/style-checker.md` (style violations). Their merged output lands at `.preflight/report.md` in the *user's* repo (not this plugin repo). `/preflight-pr` consumes that file; it does not re-run checks. Keep the report format stable across both skills.

**Stamp = proof of passing.** On a successful `/preflight` run, a `git note` is added to `HEAD`. `check-stamp.sh` validates that note's presence/format. The stamp is tied to a commit SHA, so new commits invalidate it automatically.

## Enforcement layers

Three independent layers enforce the gate. Each catches a different escape path; together they make it hard to push unchecked code without deliberately disabling the plugin.

**Layer 0 — SessionStart hook (advisory).** Runs once when a Claude Code session starts in a repo that has the plugin installed. Reads the current stamp state via `scripts/check-stamp.sh` and surfaces it to the model as session context (e.g. "HEAD is unstamped — run `/preflight` before pushing"). This is *advisory only*; it shapes Claude's behavior early in the session but does not block anything. Prevents the "forgot to run preflight" class of mistake.

**Layer 1 — Native git pre-push hook (hard gate, terminal/IDE).** `git-hooks/pre-push`, installed into `.git/hooks/pre-push` via `/install-preflight-hook`. Runs inside `git push` regardless of who invoked it — terminal, IDE, CI client, another AI tool. Calls `check-stamp.sh`; non-zero exit aborts the push. This is the layer that cannot be bypassed by switching tools away from Claude.

**Layer 2 — PreToolUse Claude hook (hard gate, in-Claude).** Registered via the plugin manifest. Intercepts Bash tool calls whose command matches `git push` *before* they execute. Calls `check-stamp.sh`; on failure, blocks the tool and returns a message explaining that `/preflight` must be run. Catches pushes Claude is about to issue, so the push never reaches Layer 1 — producing a cleaner error surface for in-Claude workflows and reducing noisy hook output in the user's terminal.

The layers are redundant by design. Removing any one of them leaves a viable bypass: remove Layer 0 and you lose early visibility; remove Layer 1 and external tools go unchecked; remove Layer 2 and Claude surfaces ugly hook stderr instead of a clean block message.

## Directory layout quirks

The structure diverges from the plan.md draft in two ways — trust the on-disk layout:
- Skills live in `skills/` (not `.claude/commands/`).
- Git hook templates live in `git-hooks/` (separate from `hooks/`, which is reserved for Claude hook scripts referenced by the plugin manifest).

## Common commands

No build, test, or lint tooling exists yet. When adding shell scripts, `chmod +x` them and prefer `bash` explicitly over `sh` for portability across macOS/Linux.
