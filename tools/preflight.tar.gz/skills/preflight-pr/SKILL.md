---
name: preflight-pr
description: Generate a PR description from the last preflight report
user-invocable: true
---

# /preflight-pr

Build a PR description from `.preflight/report.md` and optionally open the PR with `gh`. Does **not** re-run checks — the report is the contract.

## Steps

1. **Require the report.**
   Check that `.preflight/report.md` exists in the current repo. If missing:

   > No preflight report found. Run `/preflight` first to generate one.

   …and stop.

2. **Reject stale reports.**
   Parse the commit SHA from the report header (the line recording which commit was checked). Compare to `git rev-parse --short HEAD`. If they differ:

   > Report is stale — it was generated for `<report-sha>`, but HEAD is now `<head-sha>`. Re-run `/preflight` before creating the PR.

   …and stop.

3. **Verify the stamp.**
   Read the note: `git notes --ref=preflight show HEAD`. Extract `.verdict` with `jq -r '.verdict'`. If it is not `pass`:

   > HEAD's preflight verdict is `<verdict>`, not `pass`. Re-run `/preflight` and address the failures before creating the PR.

   …and stop.

4. **Compose the PR body.** Use sections in this exact order:

   ```
   ## Summary
   <intent paragraph from the report's Summary/Intent section>

   ## Reviewer Guide
   **FOCUS**
   - `<path>` — <reason from report>

   **SKIM**
   - `<path>` — <one-line note>

   <details>
   <summary>SKIP (<N> files)</summary>

   - `<path>`
   - `<path>`
   </details>

   ## Style Review
   <one-line summary: e.g. "3 violations across 2 files (see report)"; or "Clean" if none>

   ## Risk: <Low|Medium|High>
   <one-sentence justification from the report>

   ## Preflight
   - Commit: `<short-sha>`
   - Date: `<UTC timestamp from the note>`
   - Checks: pr-summary ✓ · style-review ✓
   ```

   Take the Risk level and FOCUS/SKIM/SKIP triage directly from the report — do not re-derive them.

5. **Derive the title.** Use the first line of the report's Summary/Intent section, trimmed to ≤70 characters. If unclear, ask the user for a title.

6. **Confirm before opening.** Show the user the proposed title and body, then ask:

   > Ready to run `gh pr create --title "…" --body "…"`? (yes/no)

   Only run `gh pr create` after an explicit yes. Pass the body via a heredoc to preserve formatting. Return the PR URL.

## Notes

- Never regenerate the report here. If something looks wrong, send the user back to `/preflight`.
- If `gh` is not installed, print the title + body to the conversation so the user can paste them manually.
