---
name: install-preflight-hook
description: Install the native git pre-push hook that enforces preflight
user-invocable: true
---

# /install-preflight-hook

Copy `${CLAUDE_PLUGIN_ROOT}/git-hooks/pre-push` into the current repo's `.git/hooks/pre-push`. This is Layer 1 of the enforcement model — a tool-agnostic gate that blocks any `git push` (terminal, IDE, external tool) unless HEAD carries a passing preflight stamp.

## Steps

1. **Verify this is a git repo.**
   Run `git rev-parse --git-dir`. If it fails, stop with:

   > Not a git repository — run this from inside the repo you want to protect.

   Capture the output as `$git_dir` (it may be `.git` or an absolute path for worktrees).

2. **Check for an existing hook.**
   If `${git_dir}/hooks/pre-push` already exists, read it and show the user the first ~10 lines, then ask:

   > A pre-push hook already exists at `<path>`. Overwrite it? (yes/no)

   Only proceed on explicit yes. On no, stop without changes.

3. **Install the hook.**
   Copy `${CLAUDE_PLUGIN_ROOT}/git-hooks/pre-push` to `${git_dir}/hooks/pre-push`, then `chmod +x` it. Do both in one step if possible.

4. **Confirm.** Print:

   > Installed preflight pre-push hook at `<path>`.
   > Reminder: the hook shells out to `jq` — install it (`brew install jq` / `apt-get install jq`) if you haven't already, or the hook will fail closed and block all pushes.

## Notes

- Do not touch any other hook files.
- If the user is inside a git worktree, `git rev-parse --git-dir` returns the worktree-specific hooks path — honour that; don't rewrite to `.git/hooks` blindly.
- This skill only installs Layer 1. Layer 0 (SessionStart advisory) and Layer 2 (PreToolUse block) are wired via the plugin manifest and require no per-repo install.
