#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $(basename "$0") <verdict> [pr_status] [style_status] [style_warnings]" >&2
}

if [[ $# -lt 1 ]]; then
  usage
  exit 1
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "error: jq is required but not installed" >&2
  exit 2
fi

# Normalize to lowercase so the stored note matches the verdict the enforcement
# hooks compare against; callers pass the display form (PASS/FAIL).
verdict="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')"
pr_status="${2:-unknown}"
style_status="${3:-unknown}"
style_warnings="${4:-0}"

if ! [[ "$style_warnings" =~ ^[0-9]+$ ]]; then
  echo "error: style_warnings must be a non-negative integer (got: $style_warnings)" >&2
  exit 1
fi

timestamp="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

note_json="$(jq -n \
  --arg ts "$timestamp" \
  --arg verdict "$verdict" \
  --arg pr "$pr_status" \
  --arg style "$style_status" \
  --argjson warnings "$style_warnings" \
  '{
    version: 1,
    timestamp: $ts,
    verdict: $verdict,
    checks: {
      "pr-summary": { status: $pr },
      "style-review": { status: $style, warnings: $warnings }
    }
  }')"

git notes --ref=preflight add -f -m "$note_json" HEAD

short_sha="$(git rev-parse --short HEAD)"
echo "stamped ${short_sha}: ${verdict}"
